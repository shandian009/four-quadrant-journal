import { useEffect, useState } from 'react';
import type { JournalApi } from '../shared/ipc';
import { DashboardFrame } from './components/DashboardFrame';
import { resolveTheme, type ThemeOverride } from './theme/resolve-theme';
import './styles/tokens.css';
import './styles/layout.css';

export function App({ api, now = () => new Date() }: { api?: JournalApi; now?: () => Date } = {}) {
  const journalApi = api ?? (typeof window !== 'undefined' && 'journalApi' in window ? window.journalApi : undefined);
  const [override, setOverride] = useState<ThemeOverride | null>(null);

  useEffect(() => {
    if (!journalApi) return;
    let active = true;
    void journalApi.settings.get<ThemeOverride | null>('themeOverride', null)
      .then((value) => { if (active) setOverride(value); });
    return () => { active = false; };
  }, [journalApi]);

  return <DashboardFrame
    themeId={resolveTheme(now(), override)}
    taskApi={journalApi?.tasks}
    journalApi={journalApi}
    onThemeChange={setOverride}
  />;
}
