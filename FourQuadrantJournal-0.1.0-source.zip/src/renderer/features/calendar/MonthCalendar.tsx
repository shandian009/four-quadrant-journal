import type { Task } from '../../../shared/domain';

function formatDate(year: number, month: number, day: number): string {
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function MonthCalendar({
  selectedDate,
  tasks,
  onSelect
}: {
  selectedDate: string;
  tasks: Task[];
  onSelect(date: string): void;
}) {
  const selected = new Date(`${selectedDate}T12:00:00`);
  const year = selected.getFullYear();
  const month = selected.getMonth() + 1;
  const daysInMonth = new Date(year, month, 0).getDate();
  const leading = (new Date(year, month - 1, 1).getDay() + 6) % 7;
  const cells = Array.from({ length: 42 }, (_, index) => {
    const day = index - leading + 1;
    return day >= 1 && day <= daysInMonth ? day : null;
  });

  return (
    <section className="panel task-calendar" role="region" aria-label="月历">
      <header className="panel__header"><h2>{year}年{month}月</h2></header>
      <div className="calendar-head"><span>一</span><span>二</span><span>三</span><span>四</span><span>五</span><span>六</span><span>日</span></div>
      <div className="calendar-days">
        {cells.map((day, index) => {
          if (!day) return <span key={index} className="calendar-day calendar-day--empty" />;
          const date = formatDate(year, month, day);
          const count = tasks.filter((task) => task.plannedDate === date && task.status !== 'deleted').length;
          return (
            <button
              key={date}
              type="button"
              data-testid={`calendar-day-${date}`}
              data-task-count={count}
              className={`calendar-day ${date === selectedDate ? 'calendar-day--current' : ''}`}
              onClick={() => onSelect(date)}
            >
              {day}{count > 0 && <i aria-label={`${count}项事项`} />}
            </button>
          );
        })}
      </div>
    </section>
  );
}
