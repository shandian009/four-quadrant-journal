import type { Quadrant, Task } from '../../../shared/domain';

const quadrants: Array<[Quadrant, string]> = [
  ['urgent_important', '重要且紧急'],
  ['important', '重要不紧急'],
  ['urgent', '紧急不重要'],
  ['neither', '不紧急不重要']
];

export function QuadrantBoard({ tasks, onMove }: { tasks: Task[]; onMove(id: string, quadrant: Quadrant): Promise<void> }) {
  return (
    <div className="quadrant-board">
      {quadrants.map(([quadrant, label]) => (
        <section key={quadrant} aria-label={label} className={`quadrant quadrant--${quadrant}`}>
          <h3>{label}</h3>
          {tasks.filter((task) => task.quadrant === quadrant).map((task) => (
            <article key={task.id} className="quadrant-task">
              <strong>{task.title}</strong>
              <select aria-label={`移动“${task.title}”`} value={task.quadrant} onChange={(event) => void onMove(task.id, event.target.value as Quadrant)}>
                {quadrants.map(([value, optionLabel]) => <option key={value} value={value}>{optionLabel}</option>)}
              </select>
            </article>
          ))}
        </section>
      ))}
    </div>
  );
}
