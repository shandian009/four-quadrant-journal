import { useEffect, useState } from 'react';
import type { Quadrant, Task } from '../../../shared/domain';
import type { TaskApi } from '../../../shared/ipc';
import { QuadrantBoard } from './QuadrantBoard';

export function QuadrantPage({ api, date }: { api: TaskApi; date: string }) {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    let active = true;
    void api.listByDate(date).then((items) => { if (active) setTasks(items); });
    return () => { active = false; };
  }, [api, date]);

  async function move(id: string, quadrant: Quadrant) {
    const updated = await api.update(id, { quadrant });
    setTasks((current) => current.map((task) => task.id === id ? updated : task));
  }

  return <div className="mode-page quadrant-page"><QuadrantBoard tasks={tasks} onMove={move} /></div>;
}
