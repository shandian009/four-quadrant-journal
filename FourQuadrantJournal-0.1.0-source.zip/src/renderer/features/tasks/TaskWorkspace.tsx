import { useEffect, useState } from 'react';
import type { Task } from '../../../shared/domain';
import type { CreateTaskDto, FocusApi, TaskApi } from '../../../shared/ipc';
import { MonthCalendar } from '../calendar/MonthCalendar';
import { FocusControl } from '../focus/FocusControl';
import { TaskForm } from './TaskForm';

export function TaskWorkspace({ api, initialDate, focusApi }: { api: TaskApi; initialDate: string; focusApi?: FocusApi }) {
  const [selectedDate, setSelectedDate] = useState(initialDate);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [formOpen, setFormOpen] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setError('');
    void api.listByDate(selectedDate)
      .then((items) => { if (active) setTasks(items); })
      .catch(() => { if (active) setError('读取事项失败'); });
    return () => { active = false; };
  }, [api, selectedDate]);

  async function createTask(input: CreateTaskDto) {
    const created = await api.create(input);
    setTasks((current) => [...current, created]);
    setFormOpen(false);
  }

  return (
    <div className="task-workspace">
      <section className="panel live-task-panel" role="region" aria-label="今日优先事项">
        <header className="panel__header"><h2>今日优先事项</h2><button className="text-action" type="button" aria-label="添加事项" onClick={() => setFormOpen(true)}>＋ 添加事项</button></header>
        {error && <p className="inline-error" role="alert">{error}</p>}
        <div className="task-list">
          {tasks.length === 0 && <p className="empty-state">今天还没有事项</p>}
          {tasks.map((task) => (
            <article className="task-row" key={task.id}>
              <button className="checkbox" type="button" aria-label={`完成“${task.title}”`} onClick={async () => {
                const completed = await api.complete(task.id);
                setTasks((current) => current.map((item) => item.id === task.id ? completed : item));
              }} />
              <span className="task-row__content"><strong>{task.title}</strong><small>{task.notes || '未添加说明'}</small></span>
              {focusApi && <FocusControl api={focusApi} taskId={task.id} />}
              <span className="priority priority--accent">{task.quadrant === 'urgent_important' ? '紧急' : '重要'}</span>
            </article>
          ))}
        </div>
      </section>
      <MonthCalendar selectedDate={selectedDate} tasks={tasks} onSelect={setSelectedDate} />
      {formOpen && <TaskForm plannedDate={selectedDate} onSave={createTask} onCancel={() => setFormOpen(false)} />}
    </div>
  );
}
