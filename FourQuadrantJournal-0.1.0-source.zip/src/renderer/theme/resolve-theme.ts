export type ThemeId = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday';

export interface ThemeOverride {
  themeId: ThemeId;
  mode: 'today' | 'persistent';
  date?: string;
}

function formatLocalDate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function resolveTheme(date: Date, override: ThemeOverride | null): ThemeId {
  if (override?.mode === 'persistent') return override.themeId;
  if (override?.mode === 'today' && override.date === formatLocalDate(date)) {
    return override.themeId;
  }

  const weekdayThemes: ThemeId[] = [
    'tuesday',
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'tuesday'
  ];

  return weekdayThemes[date.getDay()];
}
