import type { CSSProperties } from 'react';
import type { ThemeId } from './resolve-theme';

export interface ThemeTokens {
  label: string;
  canvas: string;
  surface: string;
  surfaceMuted: string;
  text: string;
  textMuted: string;
  accent: string;
  accentSoft: string;
  microAccent: string;
  border: string;
  danger: string;
}

export const THEMES: Record<ThemeId, ThemeTokens> = {
  monday: {
    label: '周一 · 冷启动',
    canvas: '#F1F3F4',
    surface: '#FAFBFB',
    surfaceMuted: '#E3E7EA',
    text: '#202832',
    textMuted: '#6F7B85',
    accent: '#526B80',
    accentSoft: '#DDE5EA',
    microAccent: '#C49A55',
    border: '#D4DADF',
    danger: '#B84A43'
  },
  tuesday: {
    label: '周二 · 进入状态',
    canvas: '#F4F7FA',
    surface: '#FCFDFE',
    surfaceMuted: '#E8EEF4',
    text: '#13263A',
    textMuted: '#6F8093',
    accent: '#245E9B',
    accentSoft: '#DFEAF5',
    microAccent: '#67A6B8',
    border: '#D6E0E9',
    danger: '#C14945'
  },
  wednesday: {
    label: '周三 · 周中续航',
    canvas: '#F4F1F5',
    surface: '#FCFAFC',
    surfaceMuted: '#E9E4EB',
    text: '#322A35',
    textMuted: '#7F7482',
    accent: '#63506A',
    accentSoft: '#E8E0EA',
    microAccent: '#8C7E92',
    border: '#DCD5DF',
    danger: '#A84A58'
  },
  thursday: {
    label: '周四 · 曙光将至',
    canvas: '#F3F6F2',
    surface: '#FBFCFA',
    surfaceMuted: '#E2EAE3',
    text: '#17352F',
    textMuted: '#71817B',
    accent: '#2D6F65',
    accentSoft: '#DCEAE6',
    microAccent: '#A58A58',
    border: '#D2DDD5',
    danger: '#B54B42'
  },
  friday: {
    label: '周五 · 准点下班',
    canvas: '#F7F3EC',
    surface: '#FFFCF7',
    surfaceMuted: '#EEE5D8',
    text: '#2E2924',
    textMuted: '#81766B',
    accent: '#B45F48',
    accentSoft: '#F2E0D7',
    microAccent: '#B99A62',
    border: '#E4D9CA',
    danger: '#C4473D'
  }
};

export function themeStyle(themeId: ThemeId): CSSProperties {
  const theme = THEMES[themeId];
  return {
    '--canvas': theme.canvas,
    '--surface': theme.surface,
    '--surface-muted': theme.surfaceMuted,
    '--text': theme.text,
    '--text-muted': theme.textMuted,
    '--accent': theme.accent,
    '--accent-soft': theme.accentSoft,
    '--micro-accent': theme.microAccent,
    '--border': theme.border,
    '--danger': theme.danger
  } as CSSProperties;
}
