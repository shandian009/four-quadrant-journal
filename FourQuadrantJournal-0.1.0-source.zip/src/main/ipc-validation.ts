import { z } from 'zod';

const localDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, '日期格式无效');
const optionalDateTime = z.string().datetime({ local: true }).nullable().optional().default(null);
const partialDateTime = z.string().datetime({ local: true }).nullable().optional();

export const quadrantSchema = z.enum(['urgent_important', 'important', 'urgent', 'neither']);

export const createTaskSchema = z.object({
  title: z.string().trim().min(1, '事项标题不能为空').max(120, '事项标题不能超过120个字符'),
  notes: z.string().max(5000).optional().default(''),
  quadrant: quadrantSchema,
  plannedDate: localDate,
  dueAt: optionalDateTime,
  remindAt: optionalDateTime,
  estimatedMinutes: z.number().int().positive().nullable().optional().default(null)
});

export const updateTaskSchema = z.object({
  title: z.string().trim().min(1).max(120).optional(),
  notes: z.string().max(5000).optional(),
  quadrant: quadrantSchema.optional(),
  plannedDate: localDate.optional(),
  dueAt: partialDateTime,
  remindAt: partialDateTime,
  estimatedMinutes: z.number().int().positive().nullable().optional(),
  sortOrder: z.number().int().nonnegative().optional()
});
