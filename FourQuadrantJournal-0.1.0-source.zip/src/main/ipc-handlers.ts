import type { IpcMain } from 'electron';
import { z } from 'zod';
import type { TaskRepository } from './repositories/tasks';
import type { DailyReviewRepository } from './repositories/reviews';
import { calculateStatistics } from './services/statistics';
import type { FocusRepository } from './repositories/focus';
import type { FocusTimer } from './services/focus-timer';
import type { ReminderRepository } from './repositories/reminders';
import { createTaskSchema, updateTaskSchema } from './ipc-validation';

export function registerTaskIpc(
  ipcMain: Pick<IpcMain, 'handle'>,
  tasks: TaskRepository,
  reminders?: ReminderRepository
): void {
  ipcMain.handle('tasks:listByDate', (_event, date: unknown) => {
    if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('日期格式无效');
    return tasks.findByDate(date);
  });
  ipcMain.handle('tasks:create', (_event, input: unknown) => {
    const task = tasks.create(createTaskSchema.parse(input));
    reminders?.upsertForTask(task);
    return task;
  });
  ipcMain.handle('tasks:update', (_event, id: unknown, patch: unknown) => {
    if (typeof id !== 'string') throw new Error('事项编号无效');
    const task = tasks.update(id, updateTaskSchema.parse(patch));
    reminders?.upsertForTask(task);
    return task;
  });
  ipcMain.handle('tasks:complete', (_event, id: string) => tasks.complete(id));
  ipcMain.handle('tasks:restore', (_event, id: string) => tasks.restore(id));
  ipcMain.handle('tasks:remove', (_event, id: string) => tasks.softDelete(id));
}

export function registerReviewIpc(
  ipcMain: Pick<IpcMain, 'handle'>,
  tasks: TaskRepository,
  reviews: DailyReviewRepository,
  focus: FocusRepository
): void {
  ipcMain.handle('reviews:get', (_event, date: string) => reviews.findByDate(date));
  ipcMain.handle('reviews:save', (_event, date: string, input: unknown) => {
    const parsed = zReview.parse(input);
    return reviews.save(date, parsed);
  });
  ipcMain.handle('statistics:forDate', (_event, date: string) => calculateStatistics(tasks.findByDate(date), [focus.totalForDate(date)]));
}

export function registerFocusIpc(ipcMain: Pick<IpcMain, 'handle'>, timer: FocusTimer): void {
  ipcMain.handle('focus:current', () => timer.current());
  ipcMain.handle('focus:start', (_event, taskId: string | null) => timer.start(taskId));
  ipcMain.handle('focus:pause', (_event, id: string) => timer.pause(id));
  ipcMain.handle('focus:resume', (_event, id: string) => timer.resume(id));
  ipcMain.handle('focus:finish', (_event, id: string) => timer.finish(id));
}

const zReview = createReviewSchema();

function createReviewSchema() {
  const text = z.string().max(5000);
  return z.object({ wins: text, improvements: text, tomorrowFocus: text });
}
