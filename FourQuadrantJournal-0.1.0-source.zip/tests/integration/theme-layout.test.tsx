import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { DashboardFrame } from '../../src/renderer/components/DashboardFrame';

describe('weekday skin layout parity', () => {
  it('keeps dashboard regions unchanged between Monday and Friday', () => {
    const { rerender } = render(<DashboardFrame themeId="monday" />);
    const mondayRegions = screen.getAllByTestId(/^dashboard-region-/).map((node) => node.dataset.testid);

    rerender(<DashboardFrame themeId="friday" />);
    const fridayRegions = screen.getAllByTestId(/^dashboard-region-/).map((node) => node.dataset.testid);

    expect(fridayRegions).toEqual(mondayRegions);
    expect(screen.getByTestId('application-shell')).toHaveAttribute('data-theme', 'friday');
    expect(screen.getByText('周五 · 准点下班')).toBeVisible();
  });

  it('renders the approved dashboard regions', () => {
    render(<DashboardFrame themeId="tuesday" />);

    expect(screen.getByRole('navigation', { name: '主导航' })).toBeVisible();
    expect(screen.getByRole('region', { name: '今日优先事项' })).toBeVisible();
    expect(screen.getByRole('region', { name: '月历' })).toBeVisible();
    expect(screen.getByRole('region', { name: '今日概览' })).toBeVisible();
    expect(screen.getByRole('region', { name: '今日复盘' })).toBeVisible();
  });
});
