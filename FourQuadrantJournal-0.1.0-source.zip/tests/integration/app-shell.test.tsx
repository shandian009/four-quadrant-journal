import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { App } from '../../src/renderer/App';

describe('application shell', () => {
  it('renders the product identity and dashboard heading', () => {
    render(<App />);

    expect(screen.getByText('四象日志')).toBeVisible();
    expect(screen.getByRole('heading', { name: '今日工作台' })).toBeVisible();
  });
});
