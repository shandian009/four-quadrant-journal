import Database from 'better-sqlite3';
import { describe, expect, it } from 'vitest';
import { openDatabase } from '../../src/main/database';
import { migrate } from '../../src/main/migrations';

describe('database migrations', () => {
  it('creates schema version 1 and is idempotent', () => {
    const db = new Database(':memory:');

    migrate(db);
    migrate(db);

    const tables = db
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name")
      .all()
      .map((row) => (row as { name: string }).name);
    const version = db.prepare('SELECT version FROM schema_meta').get() as { version: number };

    expect(tables).toEqual(expect.arrayContaining([
      'daily_reviews',
      'focus_sessions',
      'reminders',
      'schema_meta',
      'settings',
      'tasks'
    ]));
    expect(version.version).toBe(1);
    db.close();
  });

  it('opens a ready-to-use database', () => {
    const db = openDatabase(':memory:');
    const version = db.prepare('SELECT version FROM schema_meta').get() as { version: number };

    expect(version.version).toBe(1);
    expect((db.pragma('foreign_keys', { simple: true }) as number)).toBe(1);
    db.close();
  });
});
