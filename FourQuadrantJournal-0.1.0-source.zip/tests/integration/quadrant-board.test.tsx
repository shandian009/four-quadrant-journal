import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import type { Task } from '../../src/shared/domain';
import { QuadrantBoard } from '../../src/renderer/features/tasks/QuadrantBoard';

const task: Task = {
  id: 'task-1', title: '整理资料', notes: '', quadrant: 'urgent_important',
  plannedDate: '2026-07-10', dueAt: null, remindAt: null, estimatedMinutes: null,
  status: 'active', sortOrder: 0, completedAt: null,
  createdAt: '2026-07-10T09:00:00.000Z', updatedAt: '2026-07-10T09:00:00.000Z'
};

it('moves a task to another quadrant', async () => {
  const user = userEvent.setup();
  const onMove = vi.fn().mockResolvedValue(undefined);
  render(<QuadrantBoard tasks={[task]} onMove={onMove} />);

  await user.selectOptions(screen.getByLabelText('移动“整理资料”'), 'important');

  expect(onMove).toHaveBeenCalledWith('task-1', 'important');
});
