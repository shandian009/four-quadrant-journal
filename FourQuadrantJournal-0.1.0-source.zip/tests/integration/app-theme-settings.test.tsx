import { render, screen } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import type { JournalApi } from '../../src/shared/ipc';
import { App } from '../../src/renderer/App';

it('loads a persisted theme override', async () => {
  const api = {
    reviews: { get: vi.fn().mockResolvedValue(null), save: vi.fn() },
    statistics: { forDate: vi.fn().mockResolvedValue({ planned: 0, completed: 0, pending: 0, completionRate: 0, focusSeconds: 0 }) },
    settings: { get: vi.fn().mockResolvedValue({ themeId: 'wednesday', mode: 'persistent' }) }
  } as unknown as JournalApi;
  render(<App api={api} now={() => new Date('2026-07-06T09:00:00')} />);

  expect(await screen.findByText('周三 · 周中续航')).toBeVisible();
});
