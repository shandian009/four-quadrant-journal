import Database from 'better-sqlite3';
import { beforeEach, describe, expect, it } from 'vitest';
import { migrate } from '../../src/main/migrations';
import { TaskRepository } from '../../src/main/repositories/tasks';

describe('TaskRepository', () => {
  let db: Database.Database;
  let repo: TaskRepository;

  beforeEach(() => {
    db = new Database(':memory:');
    migrate(db);
    repo = new TaskRepository(db, () => new Date('2026-07-10T09:00:00.000Z'));
  });

  it('creates and moves a task without losing identity', () => {
    const task = repo.create({
      title: '提交项目报告',
      notes: '复核后发送',
      quadrant: 'urgent_important',
      plannedDate: '2026-07-10'
    });

    const moved = repo.update(task.id, { quadrant: 'important' });

    expect(moved).toMatchObject({
      id: task.id,
      title: '提交项目报告',
      quadrant: 'important',
      status: 'active'
    });
    expect(repo.findByDate('2026-07-10')).toHaveLength(1);
  });

  it('completes and restores a task', () => {
    const task = repo.create({
      title: '确认会议材料',
      quadrant: 'urgent',
      plannedDate: '2026-07-10'
    });

    expect(repo.complete(task.id).completedAt).toBe('2026-07-10T09:00:00.000Z');
    expect(repo.restore(task.id)).toMatchObject({ status: 'active', completedAt: null });
  });

  it('soft deletes without returning the task in date results', () => {
    const task = repo.create({
      title: '删除测试',
      quadrant: 'neither',
      plannedDate: '2026-07-10'
    });

    repo.softDelete(task.id);

    expect(repo.findByDate('2026-07-10')).toEqual([]);
  });
});
