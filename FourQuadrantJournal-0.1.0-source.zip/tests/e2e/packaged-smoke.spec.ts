import { _electron as electron, expect, test } from '@playwright/test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

const executablePath = process.env.PACKAGED_APP_PATH;

test.skip(!executablePath, '仅在 Windows 打包产物验证阶段运行');

test('packaged Windows app opens a visible workbench', async () => {
  const userData = mkdtempSync(path.join(tmpdir(), 'four-quadrant-packaged-'));
  const application = await electron.launch({
    executablePath,
    env: {
      ...process.env,
      FOUR_QUADRANT_USER_DATA: userData,
      E2E_EXIT_ON_CLOSE: '1',
      ELECTRON_ENABLE_LOGGING: '1'
    }
  });

  try {
    const window = await application.firstWindow({ timeout: 20_000 });
    await expect(window.getByRole('heading', { name: '今日工作台' })).toBeVisible({ timeout: 10_000 });
  } finally {
    await application.close().catch(() => undefined);
    rmSync(userData, { recursive: true, force: true });
  }
});
