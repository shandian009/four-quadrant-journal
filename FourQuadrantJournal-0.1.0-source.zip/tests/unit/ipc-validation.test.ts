import { describe, expect, it } from 'vitest';
import { createTaskSchema, updateTaskSchema } from '../../src/main/ipc-validation';

describe('task IPC validation', () => {
  it('rejects an empty title', () => {
    expect(() => createTaskSchema.parse({
      title: '   ',
      quadrant: 'important',
      plannedDate: '2026-07-10'
    })).toThrow('事项标题不能为空');
  });

  it('rejects an unknown quadrant', () => {
    expect(() => createTaskSchema.parse({
      title: '提交报告',
      quadrant: 'later',
      plannedDate: '2026-07-10'
    })).toThrow();
  });

  it('normalizes a valid task', () => {
    expect(createTaskSchema.parse({
      title: '  提交报告  ',
      quadrant: 'urgent_important',
      plannedDate: '2026-07-10'
    })).toMatchObject({ title: '提交报告', notes: '', remindAt: null });
  });

  it('does not clear omitted reminder fields during a partial update', () => {
    expect(updateTaskSchema.parse({ quadrant: 'important' })).toEqual({ quadrant: 'important' });
  });
});
