import { describe, expect, it } from 'vitest';
import { assertThemeParity } from '../../src/build/verify-theme-parity';
import { findNetworkViolations } from '../../src/build/verify-no-network';

describe('release verification tools', () => {
  it('accepts theme sets with identical token keys', () => {
    expect(() => assertThemeParity({ a: { one: '#fff', two: '#000' }, b: { one: '#eee', two: '#111' } })).not.toThrow();
  });

  it('rejects a theme missing a token', () => {
    expect(() => assertThemeParity({ a: { one: '#fff', two: '#000' }, b: { one: '#eee' } })).toThrow('主题令牌不一致');
  });

  it('finds business network primitives', () => {
    expect(findNetworkViolations('const data = fetch("https://example.com")')).toEqual(expect.arrayContaining(['fetch(', 'https://']));
    expect(findNetworkViolations('const value = localStorage.getItem("x")')).toEqual([]);
  });
});
