import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('desktop package configuration', () => {
  it('points Electron at the CommonJS main-process bundle emitted by tsup', () => {
    const packageJson = JSON.parse(readFileSync('package.json', 'utf8')) as { main?: string };
    expect(packageJson.main).toBe('dist-electron/main.cjs');
  });
});
